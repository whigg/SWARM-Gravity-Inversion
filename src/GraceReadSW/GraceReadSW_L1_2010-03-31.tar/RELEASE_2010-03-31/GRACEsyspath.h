/* $Id: GRACEsyspath.h,v 1.1 2009/06/03 22:53:17 glk Exp glk $ */

const int8_t *GRACESystemPath = "/goa/local/grace/includes";
